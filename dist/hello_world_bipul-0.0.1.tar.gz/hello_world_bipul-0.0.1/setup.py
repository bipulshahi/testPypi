from setuptools import setup, find_packages

setup(name='hello_world_bipul',
      version='0.0.1',
      description='A hello world example package',
      author='Bipul',
      author_email='bipul@python.net',
      url='https://www.bipul.com',
      packages=find_packages(),
      classifiers=[
          "Programming Language :: Python :: 3",
          "License :: OSI Approved :: MIT License",
          "Operating System :: OS Independent"
      ]
     )